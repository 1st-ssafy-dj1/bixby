module.exports.function = function openOnair (vliveOnair) {
  const console = require('console');

  return vliveOnair.videoUrl;
}
